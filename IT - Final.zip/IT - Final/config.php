<?php 
$con = mysqli_connect("localhost","root","12345","puee");
?>