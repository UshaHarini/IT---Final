<?php

session_start();

$username=$_SESSION["username"];

$con = mysqli_connect('localhost', 'root', '12345', 'clubs');
$id =mysqli_real_escape_string($con,$_POST['id']);
$move = "/xampp/htdocs/LAMP/notice/";
$query = "select * from notice where id='$id'";
$r=mysqli_query($con, $query);
$result=mysqli_fetch_array($r);
$file=$move.''.$result[1];
unlink($file);
$query = "delete from notice where id='$id'";
if(mysqli_query($con, $query)){
            if($username == 'Curricular'){?><script type='text/javascript'>alert('Notice Removed Successfully');
    window.location.assign("curricular.html")
</script>";
		<?php
//header('Location: curricular.html');
}
elseif($username == 'Extra Curricular'){?><script type='text/javascript'>alert('Notice Removed Successfully');
    window.location.assign("extra_curricular.html")
</script>";
		<?php
//header('Location: extra_curricular.html');
}
elseif($username == 'Sports'){?><script type='text/javascript'>alert('Notice Removed Successfully');
    window.location.assign("sports.html")
</script>";
		<?php
//header('Location: sports.html');
}
else{?><script type='text/javascript'>alert('Notice Removed Successfully');
    window.location.assign("superadmin.html")
</script>";
		<?php
//header('Location: superadmin.html');
}
		}
		else{
			if($username == 'Curricular'){?><script type='text/javascript'>alert('Notice Not Removed Successfully');
    window.location.assign("curricular.html")
</script>";
		<?php
//header('Location: curricular.html');
}
elseif($username == 'Extra Curricular'){?><script type='text/javascript'>alert('Notice Not Removed Successfully');
    window.location.assign("extra_curricular.html")
</script>";
		<?php
//header('Location: extra_curricular.html');
}
elseif($username == 'Sports'){?><script type='text/javascript'>alert('Notice Not Removed Successfully');
    window.location.assign("sports.html")
</script>";
		<?php
//header('Location: sports.html');
}
else{?><script type='text/javascript'>alert('Notice Not Removed Successfully');
    window.location.assign("superadmin.html")
</script>";
		<?php
//header('Location: superadmin.html');
}
		}
mysqli_close($con);

?>