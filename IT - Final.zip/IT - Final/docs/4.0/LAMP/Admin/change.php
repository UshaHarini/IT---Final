<?php

//Data Base Connection
$con = mysqli_connect('localhost','root','12345','clubs') or die ("Database Connection Failed");

//Declaring Variables for Data Entry
$username=mysqli_real_escape_string($con,$_POST['username']);
$password=mysqli_real_escape_string($con,$_POST['password']);
$cpassword=mysqli_real_escape_string($con,$_POST['cpassword']);


//Checking the Entered Passwords
if($password == $cpassword)
{
		
		//Checking the values are existing in the database or not
		$query = "update admin set password='$password' where username='$username'";
 
		mysqli_query($con, $query);
		?><script type='text/javascript'>alert('Password Changed');
		function newDoc() {
    window.location.assign("superadmin.html")
}newDoc();</script>";  
		<?php //header("location: superadmin.html");
		
}
else
{
	?><script type='text/javascript'>alert('Passwords Miss-Match  ');</script>";
    <?php header("location: index.html");
}
mysqli_close($con);

?>