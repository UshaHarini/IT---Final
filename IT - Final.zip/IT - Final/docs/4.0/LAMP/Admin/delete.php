<?php
session_start();
?>
<?php
$con = mysqli_connect('localhost','root','12345','clubs') or die ("Database Connection Failed");
$username=$_SESSION['username'];
$r=$_SESSION['result'];

if($username == 'Curricular'){
$query = "delete from nc where notice='$r'";}
elseif($username == 'Extra Curricular'){
$query = "delete from nec where notice='$r'";}
elseif($username == 'Sports'){
$query = "delete from ns where notice='$r'";}
else{
$query = "delete from nsa where notice='$r'";}
$rs=mysqli_query($con, $query);


/*echo '<center><table>';
while($result=mysqli_fetch_array($rs))
{
$r=$result[0];
$_SESSION['result']=$r;

echo '<center><tr><td><b><p style="color:white;">'.$r.'</p></b></td><td><a href="delete.php"><p style="color:white;"><pre style="color:red;"><u><i>Delete
</i></u></pre></p></a></td></tr></center>';
}
echo '</table></center>';*/

if($username == 'Curricular'){?><script type='text/javascript'>alert('Notice Deleted');
    window.location.assign("curricular.html")
</script>";
		<?php
//header('Location: curricular.html');
}
elseif($username == 'Extra Curricular'){?><script type='text/javascript'>alert('Notice Deleted');
    window.location.assign("extra_curricular.html")
</script>";
		<?php
//header('Location: extra_curricular.html');
}
elseif($username == 'Sports'){?><script type='text/javascript'>alert('Notice Deleted');
    window.location.assign("sports.html")
</script>";
		<?php
//header('Location: sports.html');
}
else{?><script type='text/javascript'>alert('Notice Deleted');
    window.location.assign("superadmin.html")
</script>";
		<?php
//header('Location: superadmin.html');
}
mysqli_close($con);
?>