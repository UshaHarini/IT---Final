<?php session_start();
?>
<?php 
$username=$_SESSION['username'];
$con=mysqli_connect('localhost','root','12345','clubs');
$os=mysqli_real_escape_string($con,$_POST['os']);
if($username == 'Curricular'){
$sql="select * from c where username='$os'";}
elseif($username == 'Extra Curricular'){
$sql="select * from ec where username='$os'";}
else{
$sql="select * from s where username='$os'";}
$result=mysqli_query($con, $sql);
$r=mysqli_fetch_array($result);
if($r[0] == $os)
{
	?><script type='text/javascript'>alert('Student Already A Member');
    window.location.assign("ar.php")</script>";  
		<?php
}
else{
if($username == 'Curricular'){
$sql1="insert into c values ('$os')";}
elseif($username == 'Extra Curricular'){
$sql1="insert into ec values ('$os')";}
else{
$sql1="insert into s values ('$os')";}
mysqli_query($con, $sql1);
?><script type='text/javascript'>alert('Student Already A Member');
    window.location.assign("ar.php")</script>";  
		<?php
}
mysqli_close($con);
?>