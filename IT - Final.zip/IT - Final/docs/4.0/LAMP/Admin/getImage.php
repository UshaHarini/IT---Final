<?php
session_start();?><html>
<body>
<?php
$username=$_SESSION["username"];
$conn = mysqli_connect("localhost", "root", "12345", "clubs");
$move="/xampp/htdocs/LAMP/notice/";
$sql = "SELECT * FROM notice WHERE username='$username'";
$result = mysqli_query($conn,$sql);
while($row = mysqli_fetch_array($result)){
$ra=$move.$row[1];
echo file_get_contents($ra);
}
mysqli_close($conn);
?></body></html>