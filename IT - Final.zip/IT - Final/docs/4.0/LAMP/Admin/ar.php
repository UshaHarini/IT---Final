<?php
 session_start();
?>
<!DOCTYPE html>

<html>
<head>
		<meta charset="utf-8" /><script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
	</head><body class="homepage" style="color:white;"><table><th>Username</th><th>Name</th><th>Message</th>
	<div id="page-wrapper">
			<!-- Header -->
				<div id="header-wrapper">
					<div class="container">

						<!-- Header -->
							<header id="header">
								<div class="inner">

									<!-- Logo -->
										<h1><a href="index.html" id="logo">Presidency University</a></h1>

									<!-- Nav -->
										<nav id="nav">
											<ul>
														<li><a href="response.php">Responce</a></li>
												
														<li><a href="ar.php">Accept Request</a></li>
														<li><a href="rs.html">Remove Students</a></li>
												<li><a href="https://calendar.google.com/calendar/embed?src=i0q533u426vfv4hru3hjidlj3o%40group.calendar.google.com&ctz=Asia%2FCalcutta">Edit Events</a></li>
												<li><a href="logout.php">LogOut</a></li>
											</ul>
										</nav>

								</div>
							</header><section class="container box feature1"><div id="header-wrapper">
					<div class="container"><h1 style="color:white";> ADD OTHER STUDENTS</h1>
							<form action="os.php" method="post">Username:
<input type="text" name="os" required /><br><br>
<input type="submit" value="ADD" name="submit"/>
</form></div></div></section>
	
<?php
$username=$_SESSION['username'];
$conn = new mysqli('localhost', 'root', '12345') or die (mysqli_error()); // DB Connection
$db = mysqli_select_db($conn, 'clubs') or die("DB Error"); // Select DB from database
//Selecting Database
if($username == 'Curricular'){
$sql="select * from req where club='".$username."'";}
elseif($username == 'Extra Curricular'){
$sql="select * from req where club='".$username."'";}
elseif($username == 'Sports'){
$sql="select * from req where club='".$username."'";}
else{
$sql="select * from req where club='".$username."'";}

$result = $conn->query($sql);
//Result Message
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_array()) {
?><section>
									<div class="container" style="color:white;">
										<div class="12u" >
<center><tr><p style="color:white;">
<td><center><?php echo $row['username']; ?></center></td>
<td><center><?php echo $row['name']; ?></center></td></p>
<td><center><?php echo $row['mes']; ?></center></td></p>
</tr></center></div></div></section>

</table>
<br><br>
<center>Accept Student:</center>
<form action="" method="post">
Username<input type="text" name="acc"></p>

<input type="submit" value="add" name="submit"><br/>
</form>
<?php
//$user = $_POST['rem'];
$nuser = $_POST['acc'];
$conn = new mysqli('localhost', 'root', '12345') or die (mysqli_error()); // DB Connection
 $db = mysqli_select_db($conn, 'clubs') or die("DB Error"); // Select DB from database
 if($username == 'Curricular'){
$query = mysqli_query($conn, " DELETE FROM req WHERE username='".$nuser."'");
$query = mysqli_query($conn, " insert into c(username) values('$nuser')");}
elseif($username == 'Extra Curricular'){
$query = mysqli_query($conn, " DELETE FROM req WHERE username='".$nuser."'");
$query = mysqli_query($conn, " insert into ec(username) values('$nuser')");}
elseif($username == 'Sports'){
$query = mysqli_query($conn, " DELETE FROM req WHERE username='".$nuser."'");
$query = mysqli_query($conn, " insert into s(username) values('$nuser')");}
?><center>Remove Student Request:</center>
<form action="" method="post">
Username<input type="text" name="rem"></p>

<input type="submit" value="add" name="submit"><br/>
</form>
<?php
$user = $_POST['rem'];
//$nuser = $_POST['acc'];
$conn = new mysqli('localhost', 'root', '12345') or die (mysqli_error()); // DB Connection
 $db = mysqli_select_db($conn, 'clubs') or die("DB Error"); // Select DB from database
$query = mysqli_query($conn, " DELETE FROM req WHERE username='".$user."'");
}}
else
{
echo "0 results";
}
//$conn->close();
?>
</div></div></div>
</body>
</html>