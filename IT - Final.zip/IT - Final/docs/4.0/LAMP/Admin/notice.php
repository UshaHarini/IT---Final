<?php
session_start();
?>
<?php 
$con = mysqli_connect('localhost','root','12345','clubs') or die ("Database Connection Failed");
$username=$_SESSION['username'];

$sql="select * from notice where username='$username'";

$rs=mysqli_query($con, $sql);
echo '<center><table>';
echo '<center><table style="color:white;"><tr><th><center>ID</center></th><th><center>Notices</center></th></tr>';
while($result=mysqli_fetch_array($rs))
{
$r=$result[0];
//$_SESSION['result']=$r;

/*echo '<center><tr><td><b><p style="color:white;">'.$r.'</p></b></td><td><a href="delete.php"><p style="color:white;"><pre style="color:red;"><u><i>Delete
</i></u></pre></p></a></td></tr></center>';*/
echo '<center>'.'<tr>
<td>'.'<br>'.'<b><p>'.'<center>'.$result[0].'</center></td>&nbsp&nbsp<td><center>'.$result[1].'</center></p>'.'</b>'.'</td>
</tr>'.'</center>';
}
echo '</table></center>';
?>