<?php
session_start();?>

<?php
//Data Base Connection
$con = mysqli_connect('localhost','root','12345','clubs') or die ("Database Connection Failed");

//Declaring Variables for Data Entry
$username=$_SESSION['username'];
$query = "select * from ec where username='$username'";

//Checking the Entered Passwords
if(mysqli_query($con, $query)== TRUE)
{

		?><script type='text/javascript'>alert('Extra Curricular');
    window.location.assign("ec.html")
</script>";
		<?php
		
}
else
{
	?><script type='text/javascript'>alert('You are not a member of Extra Curricular');
    window.location.assign("clubs.html")
</script>";
    <?php header("location: index.html");
}
mysqli_close($con);

?>