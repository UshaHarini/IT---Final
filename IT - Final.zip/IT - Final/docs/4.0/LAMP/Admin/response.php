<?php
session_start();
?>
<html>
<head>
<meta charset="utf-8" /><script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
</head>
<body style="color:white;"><br><table><tr><center><td>Username</td><td>Name</td><td>Query</td></center></tr>

<?php
$con = mysqli_connect('localhost','root','12345','clubs') or die ("Database Connection Failed");
$username=$_SESSION['username'];
//$reply=mysqli_real_escape_string($con,$_POST['relpy']);

if($username == 'Curricular'){
$query = "select * from rep_curricular";}
elseif($username == 'Extra Curricular'){
$query = "select * from rep_extra_curricular";}
elseif($username == 'Sports'){
$query = "select * from rep_sports";}
else{
$query = "select * from rep_super_admin";}
$rs=mysqli_query($con, $query);
//if(mysqli_query($con, $sql)== TRUE)
echo '<center><table>';
while($result=mysqli_fetch_array($rs))
{
$ra=$result[0];
$rb=$result[1];
$rc=$result[2];
$rd=$result[3];
//$_SESSION['result']=$rc;

echo '<center><tr><center><td><center><b><p style="color:white;">'.$rb.'</center></td><td><center>'.$ra.'</center></td><td><center>'.$rd.'</center></td></center></tr></center>';
}
echo '</table></center>';
?>
<center><form action="" method="post">
Reply:<input type="text" name="rep"></p>
<input type="submit" value="Reply" name="submit"><br/>
</form></center>
<?php
$headers = "From: presidencyuniversity.in" . "\r\n" .
"CC: admin123@gmail.com";
if(isset($_POST["submit"])){
if(!empty($_POST['rep'])){
	$rep=mysqli_real_escape_string($con,$_POST['rep']);
mail('$rc', "Reply to your Query in Student Organisation", '$rep', '$headers');
if($username == 'Curricular'){?><script type='text/javascript'>alert('Responded');
    window.location.assign("curricular.html")
</script>";
		<?php
//header('Location: curricular.html');
}
elseif($username == 'Extra Curricular'){?><script type='text/javascript'>alert('Responded');
    window.location.assign("extra_curricular.html")
</script>";
		<?php
//header('Location: extra_curricular.html');
}
elseif($username == 'Sports'){?><script type='text/javascript'>alert('Respoded');
    window.location.assign("sports.html")
</script>";
		<?php
//header('Location: sports.html');
}
else{?><script type='text/javascript'>alert('Responded');
    window.location.assign("superadmin.html")
</script>";
		<?php
//header('Location: superadmin.html');
}}
else{echo 'Problem in Sending Mail';}}
mysqli_close($con);
?>
</body></html>