<?php 
session_start();
?>
<?php
$username=$_SESSION['username'];
$con=mysqli_connect('localhost','root','12345','clubs');
$rs=mysqli_real_escape_string($con,$_POST['rs']);
if($username == 'Curricular'){
$sql="delete from c where username='$rs'";}
elseif($username == 'Extra Curricular'){
$sql="delete from ec where username='$rs'";}
else{
	$sql="delete from s where username='$rs'";}

if(mysqli_query($con, $sql)){
	?><script type='text/javascript'>alert('Student Removed');
    window.location.assign("rs.html")</script>";  
		<?php
}
else{?><script type='text/javascript'>alert('Student Not Removed');
    window.location.assign("rs.html")</script>";  
		<?php
}
mysqli_close($con);
?>