<?php

session_start();

$username=$_SESSION["username"];

$con = mysqli_connect('localhost', 'root', '12345', 'clubs');
$id =mysqli_real_escape_string($con,$_POST['id']);
$move = "/xampp/htdocs/LAMP/notice/";
$name =mysqli_real_escape_string($con,$_FILES['file']['name']);
$sql="insert into notice values('$id','$name', '$username')";
$result = $con->query($sql);
//$noc = $_FILES['file']['tmp_name'];
if(move_uploaded_file($_FILES['file']['tmp_name'],$move.$name))
{
			if($username == 'Curricular'){?><script type='text/javascript'>alert('Notice Added');
    window.location.assign("curricular.html")
</script>";
		<?php
//header('Location: curricular.html');
}
elseif($username == 'Extra Curricular'){?><script type='text/javascript'>alert('Notice Added');
    window.location.assign("extra_curricular.html")
</script>";
		<?php
//header('Location: extra_curricular.html');
}
elseif($username == 'Sports'){?><script type='text/javascript'>alert('Notice Added');
    window.location.assign("sports.html")
</script>";
		<?php
//header('Location: sports.html');
}
else{?><script type='text/javascript'>alert('Notice Added');
    window.location.assign("superadmin.html")
</script>";
		<?php
//header('Location: superadmin.html');
}
		}
		else{
			if($username == 'Curricular'){?><script type='text/javascript'>alert('Notice Not Added');
    window.location.assign("curricular.html")
</script>";
		<?php
//header('Location: curricular.html');
}
elseif($username == 'Extra Curricular'){?><script type='text/javascript'>alert('Notice Not Added');
    window.location.assign("extra_curricular.html")
</script>";
		<?php
//header('Location: extra_curricular.html');
}
elseif($username == 'Sports'){?><script type='text/javascript'>alert('Notice Not Added');
    window.location.assign("sports.html")
</script>";
		<?php
//header('Location: sports.html');
}
else{?><script type='text/javascript'>alert('Notice Not Added');
    window.location.assign("superadmin.html")
</script>";
		<?php
//header('Location: superadmin.html');
}
		}
mysqli_close($con);

?>