<?php
session_start();
?>
<?php 
$con = mysqli_connect('localhost','root','12345','clubs') or die ("Database Connection Failed");
$username=$_SESSION['username'];

if($username == 'Curricular'){
$sql="select * from c";}
elseif($username == 'Extra Curricular'){
$sql="select * from ec";}
else{
$sql="select * from s";}

$rs=mysqli_query($con, $sql);
echo '<center><table>';
echo '<center><table style="color:white;"><tr><th><center>Student Usernames</center></th></tr>';
while($result=mysqli_fetch_array($rs))
{
$r=$result[0];
//$_SESSION['result']=$r;

/*echo '<center><tr><td><b><p style="color:white;">'.$r.'</p></b></td><td><a href="delete.php"><p style="color:white;"><pre style="color:red;"><u><i>Delete
</i></u></pre></p></a></td></tr></center>';*/
echo '<center>'.'<tr>
<td>'.'<br>'.'<b><p>'.'<center>'.$result[0].'</center></td></p>'.'</b>'.'</td>
</tr>'.'</center>';
}
echo '</table></center>';
?>