<?php
 session_start();
?>
<!DOCTYPE html>

<html style="color:white;">
<head>
		<meta charset="utf-8" /><script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
	</head><body style="color:white;"><table><th>ID</th><th>Notice</th>
<?php
$username=$_SESSION['username'];
if(isset($_POST["submit"])){
if(!empty($_POST['rem'])){
$user = $_POST['rem'];

$conn = new mysqli('localhost', 'root', '12345') or die (mysqli_error()); // DB Connection
 $db = mysqli_select_db($conn, 'clubs') or die("DB Error"); // Select DB from database
 if($username == 'Curricular'){
$query = mysqli_query($conn, " DELETE FROM nc WHERE id='".$user."'");}
elseif($username == 'Extra Curricular'){
$query = mysqli_query($conn, " DELETE FROM nec WHERE id='".$user."'");}
elseif($username == 'Sports'){
$query = mysqli_query($conn, " DELETE FROM ns WHERE id='".$user."'");}
else{
$query = mysqli_query($conn, " DELETE FROM nsa WHERE id='".$user."'");}
//$query = mysqli_query($conn, " DELETE FROM nc WHERE id='".$user."'");
//$query = mysqli_query($conn, " DELETE FROM doc_login WHERE user='".$user."'");
}}
$conn = new mysqli('localhost', 'root', '12345') or die (mysqli_error()); // DB Connection
$db = mysqli_select_db($conn, 'clubs') or die("DB Error"); // Select DB from database
//Selecting Database
if($username == 'Curricular'){
$sql="select * from nc";}
elseif($username == 'Extra Curricular'){
$sql="select * from nec";}
elseif($username == 'Sports'){
$sql="select * from ns";}
else{
$sql="select * from nsa";}

$result = $conn->query($sql);
//Result Message
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
?><section>
									<div class="container" style="color:white;">
										<div class="12u" >
<center><tr><p style="color:white;">
<td><center><?php echo $row['id']; ?></center></td>
<td><center><?php echo $row['notice']; ?></center></td></p>
</tr></center></div></div></section>
<?php
}
}
else
{
echo "0 results";
}
$conn->close();
?>
</tr>
</table>

<center>
<form action="" method="post">
Remove ID:<input type="text" name="rem"></p>

<input type="submit" value="Remove" name="submit"><br/>
</form></center>




</div>
</body>
</html>
