<?php

//Session Start
session_start();

?>

<?php

//Data Base Connection
$con = mysqli_connect('localhost','root','12345','clubs') or die ("Database Connection Failed");

//Data Entry in Session
$_SESSION["username"]=mysqli_real_escape_string($con,$_POST['username']);
$_SESSION["password"]=mysqli_real_escape_string($con,$_POST['password']);


$username = $_SESSION["username"];
//Checking the values are existing in the database or not
$query = "select * from admin where username = '$username'";

$result = mysqli_query($con, $query) or die("INVALID USERNAME OR PASSWORD");
$row = mysqli_fetch_array($result);
//Checking for Access
if($username == "Super Admin" && $row[1] == $_SESSION["password"])
{
?><script type='text/javascript'>alert('Login Successfull');
    window.location.assign("superadmin.html")</script>";  
		<?php //	header("location: superadmin.html");
}
elseif($username == "Extra Curricular" && $row[1] == $_SESSION["password"])
{
?><script type='text/javascript'>alert('Login Successfull');
    window.location.assign("extra_curricular.html")</script>";  
		<?php //	header("location: extra_curricular.html");
}
elseif($username == "Curricular" && $row[1] == $_SESSION["password"])
{
	?><script type='text/javascript'>alert('Login Successfull');
    window.location.assign("curricular.html")</script>";  
		<?php //header("location: curricular.html");
}
elseif($username == "Sports" && $row[1] == $_SESSION["password"])
{
	?><script type='text/javascript'>alert('Login Successfull');
    window.location.assign("sports.html")</script>";  
		<?php //header("location: sports.html");
}
else
{
	?><script type='text/javascript'>alert('Login Not Successfull');
    window.location.assign("index.html")</script>";  
<?php
}

?>